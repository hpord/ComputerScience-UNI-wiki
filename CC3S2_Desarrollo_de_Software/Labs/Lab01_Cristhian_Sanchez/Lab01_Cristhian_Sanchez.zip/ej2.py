import smtplib

def prompt(prompt):
    return input(prompt).strip()


fromaddr = prompt("De: ")
toaddrs = prompt("Para: ").split()

"""Agregar las cabeceras From: y To: al comienzo del mensaje"""

msg = "De: %s\r\nPara: %s\r\n\r\n" % (fromaddr, ", ".join(toaddrs))

print("Ingrese su message, terminelo con ^D (Unix) o ^Z (Windows):")

while True:
    try:
        line = input()
    except EOFError:
        break
    if not line:
        break

msg = msg + line
print("La longitud del mensaje es ", len(msg))

"""usando: python -m smtpd -n -c DebuggingServer localhost:1025"""
server = smtplib.SMTP("localhost", 1025)
server.set_debuglevel(1)
server.sendmail(fromaddr, toaddrs, msg)
server.quit()
