import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


port = 2525
smtp_server = "smtp.mailtrap.io"
login = "ab1b3506cf10b1"
password = "b116e37ccaf2ba"
sender_email = input("De: ")
receiver_email = input("Para: ")
message = MIMEMultipart("alternative")
message["Subject"] = "multipart test 2"
message["From"] = sender_email
message["To"] = receiver_email
"""Escribimos la parte en formato de texto plano:"""

text = """\r\n Hola, Mira la lista de los mejores los libros de programacion de redes en:
    https://bookauthority.org/books/new-network-programming-books """

"""Escribimos la parte en formato HTML"""

html = """\r\n <html> <body> <p>Hola,<br> Mira la lista de los mejores los libros de programacion de
    redes:</p> <p><a href="https://bookauthority.org/books/new-network-programming-books "> 11 Best New
    Network Programming Books To Read In 2020!</a></p> <p>Haganos saber <strong>SUS IMPRESIONES</strong>
    Para saber que conenido es de más utilidad para usted!</p> </body> </html> """

"""Convertimos ambas partes a objetos MIMEText y los agregamos al mensaje MIMEMultipart"""
part1 = MIMEText(text, "plain")
part2 = MIMEText(html, "html")
message.attach(part1)
message.attach(part2)
"""enviar su email"""
with smtplib.SMTP("smtp.mailtrap.io", 2525) as server:
    server.login(login, password)
    server.sendmail(sender_email, receiver_email, message.as_string())
    print("Sent")
