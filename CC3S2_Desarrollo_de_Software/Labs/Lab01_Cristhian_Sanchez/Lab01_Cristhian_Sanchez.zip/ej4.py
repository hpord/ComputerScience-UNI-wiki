import smtplib
import mimetypes
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart

port = 2525
smtp_server = "smtp.mailtrap.io"
login = "ab1b3506cf10b1"
password = "b116e37ccaf2ba"
sender_email = input("De: ")
receiver_email = input("Para: ")
message = MIMEMultipart("alternative")
message["Subject"] = "multipart test 2"
message["From"] = sender_email
message["To"] = receiver_email
"""Escribimos la parte en formato de texto plano:"""

text = """\r\n Esta es una prueba enviando una imagen """

"""Escribimos la parte en formato HTML"""

html = """\
<html>
<body>
<img src="cid:myimage">
</body>
</html>
"""

"""Convertimos ambas partes a objetos MIMEText y los agregamos al mensaje MIMEMultipart"""
part1 = MIMEText(text, "plain")
part2 = MIMEText(html, "html")
message.attach(part1)
message.attach(part2)


ctype, encoding = mimetypes.guess_type("descargar.png")

if ctype is None or encoding is not None:
    # Si no se pudo averiguar el tipo de contenido, o el archivo esta comprimido,
    # utilizamos un tipo binario genérico .
    ctype = "application/octet-stream"

maintype, subtype = ctype.split("/", 1)
# Si quiere ver el tipo / subtipo descomentamos la siguiente instrucción:
print("maintype =", maintype, " Suptype= ", subtype)

with open("descargar.png", "rb") as img:
    image = MIMEImage(img.read(), _subtype=subtype)
    # Especificamos el ID de acuerdo con la etiqueta img src en la parte HTML
    image.add_header("Content-ID", "<myimage>")
    message.attach(image)

"""enviar su email"""
with smtplib.SMTP("smtp.mailtrap.io", 2525) as server:
    server.login(login, password)
    server.sendmail(sender_email, receiver_email, message.as_string())
    print("Sent")
