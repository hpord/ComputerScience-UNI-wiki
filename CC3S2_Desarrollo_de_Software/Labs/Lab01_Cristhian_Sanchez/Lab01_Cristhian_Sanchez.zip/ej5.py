import sys
from urllib import request

try:
    rfc_number = int(sys.argv[1])
except (IndexError, ValueError):
    print("Debe proporcionar un numero de RFC como primer argumento.")
    sys.exit(2)

url = "http://www.ietf.org/rfc/rfc{}.txt".format(rfc_number)
rfc_raw = request.urlopen(url).read()
rfc = rfc_raw.decode()
print(rfc)
