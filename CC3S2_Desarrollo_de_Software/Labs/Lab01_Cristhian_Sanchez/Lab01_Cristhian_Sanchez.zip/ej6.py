import ftplib
import sys
from smtplib import SMTP

FTP_HOST = "ftp.ietf.org"
filename = "rfc{}.txt".format(int(sys.argv[1]))

ftp = ftplib.FTP(FTP_HOST)
ftp.login()
ftp.cwd('rfc')    

with open(filename, "wb") as file:
    print(f"descargando archivo {filename} con protocolo FTP\n")
    ftp.retrbinary(f"RETR {filename}", file.write)
    ftp.quit()

with SMTP(FTP_HOST) as smtp:
    print(f"descargando archivo {filename} con protocolo SMTP\n")
    print(smtp.noop())