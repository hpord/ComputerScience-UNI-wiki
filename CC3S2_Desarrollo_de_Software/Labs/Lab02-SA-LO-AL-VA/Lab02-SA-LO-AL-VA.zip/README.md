# LAB02-SA-LO-AL-VA
Probando repositorio grupal

**Integrantes:**

- Cristhian Wiki Sánchez Sauñe 20180517A
- Andro Erick Valero Medina 20172757G
- Davis Keenyo Alderete Valencia 20181139K 
- Ronaldo Lopez Campomanes 20181469K
