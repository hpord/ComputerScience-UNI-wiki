var date = new Date()
let date_formated = [date.getDate(), date.getMonth() + 1, date.getFullYear()]
console.log("\nHoy es: " + date_formated[0] + "/" + date_formated[1] + "/" + date_formated[0])
console.log("\n" + date_formated[0] + "-" + date_formated[1] + "-" + date_formated[0])