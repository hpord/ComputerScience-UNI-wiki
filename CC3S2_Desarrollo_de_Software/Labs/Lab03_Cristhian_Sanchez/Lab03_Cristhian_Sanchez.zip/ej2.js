const readline = require("readline");

const IsBiciest = (anio) => {
    if (((anio % 4 == 0) && (anio % 100 != 0 )) || (anio % 400 == 0)){
        return true;
      }
    else return false;
};


const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Ingrese un año: ", function(anio) {

        console.log("\nEl año es biciesto?\n" + IsBiciest(anio))
        rl.close();
});

rl.on("close", function() {
    console.log("\nHasta luego !!!");
    process.exit(0);
});