console.log("\nEl primer arreglo es: ");
const array_1 = [1, 2, 3];
console.log(array_1);

console.log("\nGenerando segundo arreglo...");
const randomArray = (length, max) => [...new Array(length)]
    .map(() => Math.round(Math.random() * max));

const array_2 = randomArray(array_1.length, 10);
console.log(array_2);


const calculateDistance = (a, b) => {
    var distance_total = 0;
    var string_result = '';
    for (var i = 0; i < a.length; i++) {
        distance_total += Math.pow(a[i] - b[i], 2);
        string_result += " ( " + a[i].toString() + ' - ' + b[i].toString() +  " )^2  ";
        if (i != a.length - 1) { 
            string_result += " + ";
        }
    }
    console.log("\nLa sumatoria de diferencias ..");
    console.log(string_result + " = " + distance_total);

    return Math.sqrt(distance_total);
};

console.log("\nLa distancia euclideana (raíz cuadrada de la sumatoria) es: " 
            + calculateDistance(array_1, array_2));