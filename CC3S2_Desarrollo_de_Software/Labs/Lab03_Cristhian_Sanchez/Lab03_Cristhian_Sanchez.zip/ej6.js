console.log("\nImprimiendo objeto..");
const person = {"name": "Wiki", "age": 18, "sex": "male"};
console.log(person);
console.log("\nResultado: ");

var values = Object.keys(person).map(function(key){
    return person[key];
});

for (var i = 0; i < values.length; i++) {
    process.stdout.write(values[i] + " ");
}


