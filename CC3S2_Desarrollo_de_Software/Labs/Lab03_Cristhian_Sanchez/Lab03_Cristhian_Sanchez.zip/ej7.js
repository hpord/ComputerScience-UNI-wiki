console.log("\nImprimiendo objetos..");
const person1 = {"name": "Wiki", "age": 18, "sex": "male"};
const person2 = {"name": "Melissa", "age": 24, "sex": "female"};
const person3 = {"name": "Julissa", "age": 24, "sex": "female"};

const persons_array = [person1, person2, person3];

console.log(persons_array);
console.log("\n\nResultado: ");


var values_total = [];
var keys = Object.keys(persons_array[0]);
for (var i = 0; i < persons_array.length; i++){
    var values = Object.keys(persons_array[i]).map(function(key){
        return persons_array[i][key];
    });
    values_total.push(values);
}



for (var i = 0; i < values_total.length; i++) {
    for (var j = 0; j < values_total[0].length; j++) {
        process.stdout.write(values_total[i][j] + "  ");
    
    }
    process.stdout.write("\n");
    
}

console.log("\nLas propiedades son ..");
console.log(keys);



