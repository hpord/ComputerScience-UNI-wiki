'use strict';
/*
  * Este archivo prueba la TAREA de JavaScript de CC3S2 LAB03. Imprime lo que
  * busca en el registro de la consola y actualiza el texto que se muestra en la ventana con un
  * resumen de los resultados.
  */

// Suponemos que estos símbolos serán definidos globalmente por el usuario. Estas declaraciones 
// de variables asignarán el valor  undefined al símbolo si aún no es global.
// Estos símbolos globales son necesarios para probar su archivo.


var cc3s2HacerMultifiltro;

(function() {
// Mensaje de resultado para la TAREA 1
var p1Message = 'SUCCESS';

// Dar seguimiento a las variables 
var varDeclared = ['varDeclared', 'p1Message'];

// ********************* Test CC3S2 - multifiltro

if (typeof cc3s2HacerMultifiltro !== 'function') {
    console.error('cc3s2HacerMultifiltro no es una funcion', typeof cc3s2HacerMultifiltro);
    p1Message = 'FAILURE';
} else {

    var arraysAreTheSame = function arraysAreTheSame(a1, a2) {
        if (!Array.isArray(a1) || !Array.isArray(a2) || (a1.length !== a2.length)) {
            return false;
        }
        for (var i = 0; i < a1.length; i++) {
            if (a1[i] !== a2[i]) {
                return false;
            }
        }
        return true;
    };

    var originalArray = [1, 2, 3];
    var filterFunc = cc3s2HacerMultifiltro(originalArray);
    
    var secondArray = [1, 2, 3, 4];
    var filterFuncTwo = cc3s2HacerMultifiltro(secondArray);

    if (typeof filterFunc !== 'function') {
        console.error('cc3s2HacerMultifiltro no retorna una funcion', filterFunc);
        p1Message = 'FAILURE';
    } else {
        var result = filterFunc();
        if (!arraysAreTheSame([1, 2, 3], result)) {
            console.error('la funcion de filtrado sin argumentos no retorna el  arreglo original' , result);
            p1Message = 'FAILURE';
        }

        var callbackPerformed = false;
        result = filterFunc(function (item) {
            return item !== 2;
        }, function (callbackResult) {
            callbackPerformed = true;
            if (!arraysAreTheSame([1, 3], callbackResult)) {
                console.error('la funcion de filtrado  no filtra 2 correctamente' , callbackResult);
                p1Message = 'FAILURE';
            }
            if (!arraysAreTheSame([1, 2, 3], this)) {
                console.error('la funcion callback no pasa el arreglo original como this' , this);
                p1Message = 'FAILURE';
            }
        });

        if (!callbackPerformed) {
            console.error(' no se ejecutó la funcion de callback');
            p1Message = 'FAILURE';
        }

        if (result !== filterFunc) {
            console.error('la funcion de filtrado no se retorna a si misma', result);
            p1Message = 'FAILURE';
        }

        result =  filterFunc(function (item) {
            return item !== 3;
        });
        if (result !== filterFunc) {
            console.error('la funcion de filtrado no se retorna a si misma 2', result);
            p1Message = 'FAILURE';
        }

        result =  filterFunc();
        if (!arraysAreTheSame([1],result)) {
            console.error('la  funcion callback de filtrado no filtra 3 correctamente' , result);
            p1Message = 'FAILURE';
        }
        result = filterFuncTwo(function (item) {
            return item !== 1;
        }, function (callbackResult) {
            if (!arraysAreTheSame([2, 3, 4], callbackResult)) {
                console.error('el segundo filtro  not filtra 1 ( verifique el uso de la variable global )' , callbackResult);
                p1Message = 'FAILURE';
            }
            if (!arraysAreTheSame([1, 2, 3, 4], this)) {
                console.error('la  funcion callback de filtrado no pasa el arreglo  original como this' , this);
                p1Message = 'FAILURE';
            }
        });

    }


}
console.log('Test cc3s2HacerMultifiltro:', p1Message);



// Guardar el resultado de vuelta al ambito global bajo el nombre de objeto cc3s2Lab03Results
window.cc3s2Lab03Results = {
    p1Message: p1Message
};

// una vez que el navegador carga nuestra pagina HTML cc3s2-test-lab03.html 
// la actualizamos con los resultados del  testeo. 
window.onload = function () {
    document.getElementById("cc3s2p1").innerHTML = p1Message;
    
};

}());