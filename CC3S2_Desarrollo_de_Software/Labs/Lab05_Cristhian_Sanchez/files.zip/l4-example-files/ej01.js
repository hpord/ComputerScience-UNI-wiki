function Rectangle(width, height){
    this.width=width;
    this.height=height;
    this.area= function () { return this.width * this.height; }    
    }
    var r = new Rectangle(26,14);
    console.log (Object.keys(r));
    console.log(r);
    console.log(r.area());
    
