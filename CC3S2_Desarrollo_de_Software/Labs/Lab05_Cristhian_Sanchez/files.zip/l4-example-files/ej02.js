function func(arg){ console.log(this,arg);}
console.log("llamada a func.toString():");
let str=func.toString();
console.log(str);
console.log("llamada a func.call({t:1},2):");
func.call({t:1},2);
let newFunc= func.bind({z:2},3)
console.log("llamada a newFunc():");
newFunc();